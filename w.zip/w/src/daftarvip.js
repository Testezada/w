const daftarvip = (prefix) => { 
	return `
	
*PRE?O DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietario do bate-papo BOT :*

_wa.me/559885018147 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO TOBI :*
_https://chat.whatsapp.com/C4AbRhqbqAA5wBirYadusl `
}
exports.daftarvip = daftarvip
